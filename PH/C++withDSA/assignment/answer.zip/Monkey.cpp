#include <bits/stdc++.h>
using namespace std;

int main()
{

    char s[100001];
    while (cin.getline(s, 100001))
    {
        int len = strlen(s);
        for (int i = 0; i < len - 1; i++)
        {
            for (int j = i + 1; j < len; j++)
            {
                if (s[i] > s[j])
                {
                    swap(s[i], s[j]);
                }  
            }

        }

        for (int i = 0; i < len; i++)
        {
            if (s[i] == ' ')
            {
                continue;
            }
            cout << s[i];
        }

        cout << endl;
    }

    return 0;
}